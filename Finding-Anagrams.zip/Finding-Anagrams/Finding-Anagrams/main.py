# Check if two words are anagrams 
# Example:
# find_anagrams("hello", "check") --> False
# find_anagrams("below", "elbow") --> True


def find_anagram(word, anagram):
    # [assignment] Add your code here
      #str1= input("string1:")
    #str2= input("string2:")
    print("the first word is"," ' ", word,"'",  " and the second one is ","'", anagram,"'")
    word=sorted(word)
    anagram=sorted(anagram)
    
    if word==anagram :
       print("the first word after sorted is"," ' ", word,"'",  " and the second one after sorted is ","'", anagram,"'")
       return True
    else:
        return False
  
word= input("string1:")
anagram= input("string2:")
print(find_anagram(word, anagram))
